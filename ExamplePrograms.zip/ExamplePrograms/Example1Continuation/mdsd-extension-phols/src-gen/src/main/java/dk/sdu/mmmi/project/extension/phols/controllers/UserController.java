package dk.sdu.mmmi.project.extension.phols.controllers;
import dk.sdu.mmmi.project.extension.phols.models.*;
import org.springframework.web.bind.annotation.*;
import dk.sdu.mmmi.project.extension.phols.services.IUser;

import javax.validation.Valid;
import java.util.List;
import java.time.LocalDateTime;

@RestController
public class UserController {
	
	private IUser userService;
	
	public UserController(IUser userService) {
	    this.userService =  userService;
	}
	
	@PostMapping("/api/user")
	public User createUser(@Valid @RequestBody User user) {
		return userService.create(user);
	}
	
	@GetMapping("/api/user/{id}")
	public User find(@PathVariable Long id) {
		return userService.find(id);
	}
	
	@GetMapping("/api/user/all")
	public List<User> findAll() {
		return userService.findAll();
	}
	
	@PutMapping("/api/user")
	@ResponseBody
	public void update(@RequestBody User user) {
		userService.update(user);
	}
	
	@DeleteMapping("/api/user/{id}")
	@ResponseBody
	public void delete(@PathVariable Long id) {
	    userService.delete(id);
	}
	
	@PostMapping("/api/user/auth")
	Boolean auth(){
		return 	userService.auth();
	}
	
}
