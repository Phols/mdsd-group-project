package dk.sdu.mmmi.project.extension.phols.services.impl;

import dk.sdu.mmmi.project.extension.phols.models.Loan;
import dk.sdu.mmmi.project.extension.phols.models.Media;
import dk.sdu.mmmi.project.extension.phols.repositories.LoanRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class LoanImpl extends AbstractLoanImpl {
    public LoanImpl(LoanRepository repository) {
        super(repository);
    }

    @Override
    public List<Loan> underdueLoans(LocalDateTime currDate) {
        return null;
    }

    @Override
    public List<Loan> overdueLoans(LocalDateTime currDate) {
        return null;
    }

    @Override
    public List<Loan> listOfMediaLoan(Media media) {
        return null;
    }

}
