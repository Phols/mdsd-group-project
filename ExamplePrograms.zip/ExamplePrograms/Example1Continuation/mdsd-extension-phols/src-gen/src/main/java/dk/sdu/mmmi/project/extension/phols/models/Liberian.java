package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_LIBERIAN")
public class Liberian extends User {
	

	private String _name;
	
	private Integer _phoneNumber;
	
	private Integer _employeeNumber;
	
	@OneToMany(targetEntity = Loan.class, cascade = CascadeType.ALL)
	private List<Loan> _loans;
	
	
	public Liberian() { }
	
	public String getName() {
		return _name;
	}
	public Integer getPhoneNumber() {
		return _phoneNumber;
	}
	public Integer getEmployeeNumber() {
		return _employeeNumber;
	}
	public List<Loan> getLoans() {
		return _loans;
	}
	public void setName (String name)  {
		this._name = name;
	}
	
	public void setPhoneNumber (Integer phoneNumber)  {
		this._phoneNumber = phoneNumber;
	}
	
	public void setEmployeeNumber (Integer employeeNumber)  {
		this._employeeNumber = employeeNumber;
	}
	
	public void setLoans (List<Loan> loans)  {
		this._loans = loans;
	}
	
}

