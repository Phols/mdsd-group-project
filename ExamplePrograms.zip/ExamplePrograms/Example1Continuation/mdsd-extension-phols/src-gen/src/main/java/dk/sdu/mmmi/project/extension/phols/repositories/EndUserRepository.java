package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.EndUser; 
import org.springframework.data.repository.CrudRepository;
import org.springframework.context.annotation.Primary;
@Primary
public interface EndUserRepository extends UserRepository<EndUser> {
}
