package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_ADMIN")
public class Admin extends User {
	

	private String _name;
	
	private Integer _phoneNumber;
	
	private Integer _employeeNumber;
	
	
	public Admin() { }
	
	public String getName() {
		return _name;
	}
	public Integer getPhoneNumber() {
		return _phoneNumber;
	}
	public Integer getEmployeeNumber() {
		return _employeeNumber;
	}
	public void setName (String name)  {
		this._name = name;
	}
	
	public void setPhoneNumber (Integer phoneNumber)  {
		this._phoneNumber = phoneNumber;
	}
	
	public void setEmployeeNumber (Integer employeeNumber)  {
		this._employeeNumber = employeeNumber;
	}
	
}

