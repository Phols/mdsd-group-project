package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.Liberian; 
import org.springframework.data.repository.CrudRepository;
public interface LiberianRepository extends UserRepository<Liberian> {
}
