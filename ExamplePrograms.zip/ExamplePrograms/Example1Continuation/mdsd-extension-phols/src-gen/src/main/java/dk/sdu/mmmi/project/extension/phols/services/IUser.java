package dk.sdu.mmmi.project.extension.phols.services;

import java.util.List;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.models.*;

public interface IUser {
	
	User create(User _User);
	
	List<User> findAll();
	
	User find(Long id);
	
	User update(User User);
	
	void delete(Long id);
	
	void delete(User _User);
	
	Boolean auth();
	
	Boolean makeAdmin(User user  );
}
