package dk.sdu.mmmi.project.extension.phols.services;

import java.util.List;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.models.*;

public interface ILoan {
	
	Loan create(Loan _Loan);
	
	List<Loan> findAll();
	
	Loan find(Long id);
	
	Loan update(Loan Loan);
	
	List<Loan> underdueLoans(LocalDateTime currDate  );
	
	List<Loan> overdueLoans(LocalDateTime currDate  );
	
	List<Loan> listOfMediaLoan(Media media  );
}
