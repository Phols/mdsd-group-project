package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.Media; 
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean; 
import java.util.Optional;
@NoRepositoryBean
public interface MediaRepository<T extends Media> 
	extends CrudRepository<T, Long> {
}
