package dk.sdu.mmmi.project.extension.phols.security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import dk.sdu.mmmi.project.extension.phols.repositories.UserRepository;
import dk.sdu.mmmi.project.extension.phols.models.User;

@Service
public class UserDetailServiceImpl implements UserDetailsService {
	
	private UserRepository repository;
	
	public UserDetailServiceImpl(UserRepository repository) {
		super();
		this.repository = repository;
	}
		
		@Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	        User _User = repository.findBy_username(username);
	        if (_User == null) {
	            throw new UsernameNotFoundException(
	                    "No User found with username: " + username);
	        }
	        return new UserPrincipal(_User);
	    }
}
