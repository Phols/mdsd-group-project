package dk.sdu.mmmi.project.extension.phols.services.impl;

import dk.sdu.mmmi.project.extension.phols.models.User;
import dk.sdu.mmmi.project.extension.phols.repositories.UserRepository;
import org.springframework.stereotype.Component;

@Component
public class UserImpl extends AbstractUserImpl {
    public UserImpl(UserRepository repository) {
        super(repository);
    }

    @Override
    public Boolean auth() {
        return null;
    }

    @Override
    public Boolean makeAdmin(User user) {
        return null;
    }
}
