package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_ENDUSER")
public class EndUser extends User {
	

	private String _name;
	
	@OneToMany(targetEntity = Loan.class, cascade = CascadeType.ALL)
	private List<Loan> _loans;
	
	
	public EndUser() { }
	
	public String getName() {
		return _name;
	}
	public List<Loan> getLoans() {
		return _loans;
	}
	public void setName (String name)  {
		this._name = name;
	}
	
	public void setLoans (List<Loan> loans)  {
		this._loans = loans;
	}
	
}

