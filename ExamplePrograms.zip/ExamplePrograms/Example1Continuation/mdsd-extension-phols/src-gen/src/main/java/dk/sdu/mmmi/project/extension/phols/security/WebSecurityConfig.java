package dk.sdu.mmmi.project.extension.phols.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.http.HttpMethod;		

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
private static final String ALLOWED_IPS ="hasIpAddress('255.126.124.255')or hasIpAddress('125.126.124.241') or hasIpAddress('125.126.124.240') ";
private UserDetailServiceImpl detailService;

public WebSecurityConfig(UserDetailServiceImpl detailService){
	this.detailService = detailService;
}

	@Override
	protected void configure(final AuthenticationManagerBuilder auth) {
		auth.authenticationProvider(authenticationProvider());	
	}

		@Bean
		public PasswordEncoder passwordEncoder() {
			return new 
		BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	http.authorizeRequests()
	.antMatchers("/api/testsuite/loan/underdueLoans").hasIpAddress("125.126.124.240")
	.antMatchers("/api/testsuite/loan/underdueLoans").hasAnyRole("ADMIN")					
	.antMatchers(HttpMethod.GET, "/api/**").hasRole("USER")
	.antMatchers("/api/loan/listofmedialoan").hasRole("LIBERIAN")
	.antMatchers("/api/loan/overdueloans").hasRole("USER")
	;
	http.authorizeRequests().anyRequest().access(ALLOWED_IPS).and().requiresChannel().anyRequest().requiresSecure(); 
	
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(detailService);
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}	
}
