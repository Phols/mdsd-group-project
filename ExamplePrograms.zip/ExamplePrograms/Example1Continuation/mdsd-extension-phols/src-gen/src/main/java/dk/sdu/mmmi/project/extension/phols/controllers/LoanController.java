package dk.sdu.mmmi.project.extension.phols.controllers;
import dk.sdu.mmmi.project.extension.phols.models.*;
import org.springframework.web.bind.annotation.*;
import dk.sdu.mmmi.project.extension.phols.services.ILoan;

import javax.validation.Valid;
import java.util.List;
import java.time.LocalDateTime;

@RestController
public class LoanController {
	
	private ILoan loanService;
	
	public LoanController(ILoan loanService) {
	    this.loanService =  loanService;
	}
	
	@PostMapping("/api/loan")
	public Loan createLoan(@Valid @RequestBody Loan loan) {
		return loanService.create(loan);
	}
	
	@GetMapping("/api/loan/{id}")
	public Loan find(@PathVariable Long id) {
		return loanService.find(id);
	}
	
	@GetMapping("/api/loan/all")
	public List<Loan> findAll() {
		return loanService.findAll();
	}
	
	@PutMapping("/api/loan")
	@ResponseBody
	public void update(@RequestBody Loan loan) {
		loanService.update(loan);
	}
	
	@GetMapping("/api/testsuite/loan/underdueLoans")
	List<Loan> underdueLoans(@RequestParam LocalDateTime currDate){
		return 	loanService.underdueLoans(currDate);
	}
	
	@GetMapping("/api/loan/overdueloans")
	List<Loan> overdueLoans(@RequestParam LocalDateTime currDate){
		return 	loanService.overdueLoans(currDate);
	}
	
	@GetMapping("/api/loan/listofmedialoan")
	List<Loan> listOfMediaLoan(@RequestParam Media media){
		return 	loanService.listOfMediaLoan(media);
	}
	
}
