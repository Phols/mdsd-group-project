package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.Loan; 
import org.springframework.data.repository.CrudRepository;

public interface LoanRepository extends CrudRepository<Loan, Long> {
}
