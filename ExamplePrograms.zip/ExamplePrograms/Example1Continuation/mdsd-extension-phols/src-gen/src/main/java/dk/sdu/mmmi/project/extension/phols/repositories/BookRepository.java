package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.Book; 
import org.springframework.data.repository.CrudRepository;
public interface BookRepository extends MediaRepository<Book> {
}
