package dk.sdu.mmmi.project.extension.phols.services;

import java.util.List;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.models.*;

public interface IMedia {
	
	Media create(Media _Media);
	
	List<Media> findAll();
	
	Media find(Long id);
	
	Media update(Media Media);
	
	void delete(Long id);
	
	void delete(Media _Media);
}
