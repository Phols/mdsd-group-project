package dk.sdu.mmmi.project.extension.phols.security;
import com.fasterxml.jackson.annotation.JsonFormat;
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum Role {
ADMIN,
LIBERIAN,
ENDUSER,
USER,

}
	
