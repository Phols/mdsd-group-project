package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_USER")
@Inheritance
public class User {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long _id;
	
	private String _username;
	
	private String _password;
	
	@ElementCollection(targetClass = Role.class, fetch = FetchType.EAGER)
	@CollectionTable(name = "User_roles",joinColumns = @JoinColumn(name = "User_id"))
	@Enumerated(EnumType.STRING)
	@Column(name = "role_id")
	private List<Role> _roles;
	
	public User() { }
	
	public long getId() {
		return _id;
	}
	public List<Role> getRoles(){
		return _roles;	
	}
	public String getUsername() {
		return _username;
	}
	public String getPassword() {
		return _password;
	}
	public void setId (long id)  {
		this._id = id;
	}
	
	public void setUsername (String username)  {
		this._username = username;
	}
	
	public void setPassword (String password)  {
		this._password = password;
	}
	
}

