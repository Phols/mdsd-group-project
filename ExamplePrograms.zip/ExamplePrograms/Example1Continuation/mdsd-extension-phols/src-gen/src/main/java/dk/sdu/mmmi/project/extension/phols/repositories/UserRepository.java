package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.User; 
import org.springframework.data.repository.CrudRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.data.repository.NoRepositoryBean; 
import java.util.Optional;
@NoRepositoryBean
public interface UserRepository<T extends User> 
	extends CrudRepository<T, Long> {
	User findBy_username(String username);
}
