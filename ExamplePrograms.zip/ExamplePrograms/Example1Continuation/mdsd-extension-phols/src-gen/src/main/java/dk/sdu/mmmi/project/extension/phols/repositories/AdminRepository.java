package dk.sdu.mmmi.project.extension.phols.repositories;

import dk.sdu.mmmi.project.extension.phols.models.Admin; 
import org.springframework.data.repository.CrudRepository;
public interface AdminRepository extends UserRepository<Admin> {
}
