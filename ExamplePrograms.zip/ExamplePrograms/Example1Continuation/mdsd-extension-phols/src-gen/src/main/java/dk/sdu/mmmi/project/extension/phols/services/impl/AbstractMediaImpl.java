package dk.sdu.mmmi.project.extension.phols.services.impl;

import java.util.*;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.repositories.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.services.*;
import org.springframework.stereotype.Service;

public abstract class AbstractMediaImpl implements IMedia {
	
	protected MediaRepository repository;
	
	public AbstractMediaImpl(MediaRepository repository) {
		this.repository = repository;
	}
	
	
	@Override
	public Media create(Media _Media) {
		return (Media)repository.save(_Media);
	}
	
	@Override
	public List<Media> findAll() {
		List<Media> all = new ArrayList<>();
		repository.findAll().forEach(x -> all.add((Media) x));
		return all; 					
	}
	
	@Override
	public Media find(Long id) {
		return (Media)repository.findById(id).get();
	}
	
	@Override
	public Media update(Media _Media) {
		return (Media)repository.save(_Media);
	}
	
	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
	@Override
	public void delete(Media _Media) {
		repository.delete(_Media);
	}
	
}
