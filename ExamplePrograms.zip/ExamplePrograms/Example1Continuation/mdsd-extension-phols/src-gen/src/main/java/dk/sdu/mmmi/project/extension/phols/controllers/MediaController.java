package dk.sdu.mmmi.project.extension.phols.controllers;
import dk.sdu.mmmi.project.extension.phols.models.*;
import org.springframework.web.bind.annotation.*;
import dk.sdu.mmmi.project.extension.phols.services.IMedia;

import javax.validation.Valid;
import java.util.List;
import java.time.LocalDateTime;

@RestController
public class MediaController {
	
	private IMedia mediaService;
	
	public MediaController(IMedia mediaService) {
	    this.mediaService =  mediaService;
	}
	
	@PostMapping("/api/media")
	public Media createMedia(@Valid @RequestBody Media media) {
		return mediaService.create(media);
	}
	
	@GetMapping("/api/media/{id}")
	public Media find(@PathVariable Long id) {
		return mediaService.find(id);
	}
	
	@GetMapping("/api/media/all")
	public List<Media> findAll() {
		return mediaService.findAll();
	}
	
	@PutMapping("/api/media")
	@ResponseBody
	public void update(@RequestBody Media media) {
		mediaService.update(media);
	}
	
	@DeleteMapping("/api/media/{id}")
	@ResponseBody
	public void delete(@PathVariable Long id) {
	    mediaService.delete(id);
	}
	
}
