package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_MEDIA")
@Inheritance
public class Media {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long _id;
	
	private String _name;
	
	private LocalDateTime _published;
	
	
	public Media() { }
	
	public long getId() {
		return _id;
	}
	public String getName() {
		return _name;
	}
	public LocalDateTime getPublished() {
		return _published;
	}
	public void setId (long id)  {
		this._id = id;
	}
	
	public void setName (String name)  {
		this._name = name;
	}
	
	public void setPublished (LocalDateTime published)  {
		this._published = published;
	}
	
}

