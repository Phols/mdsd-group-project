package dk.sdu.mmmi.project.extension.phols.services.impl;

import dk.sdu.mmmi.project.extension.phols.repositories.MediaRepository;
import org.springframework.stereotype.Component;

@Component
public class BookImpl extends AbstractMediaImpl {
    public BookImpl(MediaRepository repository) {
        super(repository);
    }
}
