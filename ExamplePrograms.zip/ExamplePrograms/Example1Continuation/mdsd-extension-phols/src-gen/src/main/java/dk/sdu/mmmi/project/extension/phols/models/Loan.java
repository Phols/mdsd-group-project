package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_LOAN")
public class Loan {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long _id;
	
	private LocalDateTime _startDate;
	
	private LocalDateTime _endDate;
	
	private LocalDateTime _archivedDate;
	
	private Boolean _returned;
	
	@OneToOne(targetEntity = User.class, cascade = CascadeType.ALL)
	private User _user;
	
	@OneToOne(targetEntity = Media.class, cascade = CascadeType.ALL)
	private Media _loaned;
	
	
	public Loan() { }
	
	public long getId() {
		return _id;
	}
	public LocalDateTime getStartDate() {
		return _startDate;
	}
	public LocalDateTime getEndDate() {
		return _endDate;
	}
	public LocalDateTime getArchivedDate() {
		return _archivedDate;
	}
	public Boolean getReturned() {
		return _returned;
	}
	public User getUser() {
		return _user;
	}
	public Media getLoaned() {
		return _loaned;
	}
	public void setId (long id)  {
		this._id = id;
	}
	
	public void setStartDate (LocalDateTime startDate)  {
		this._startDate = startDate;
	}
	
	public void setEndDate (LocalDateTime endDate)  {
		this._endDate = endDate;
	}
	
	public void setArchivedDate (LocalDateTime archivedDate)  {
		this._archivedDate = archivedDate;
	}
	
	public void setReturned (Boolean returned)  {
		this._returned = returned;
	}
	
	public void setUser (User user)  {
		this._user = user;
	}
	
	public void setLoaned (Media loaned)  {
		this._loaned = loaned;
	}
	
}

