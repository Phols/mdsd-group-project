package dk.sdu.mmmi.project.extension.phols.services.impl;

import java.util.*;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.repositories.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.services.*;
import org.springframework.stereotype.Service;

public abstract class AbstractUserImpl implements IUser {
	
	protected UserRepository repository;
	
	public AbstractUserImpl(UserRepository repository) {
		this.repository = repository;
	}
	
	
	@Override
	public User create(User _User) {
		return (User)repository.save(_User);
	}
	
	@Override
	public List<User> findAll() {
		List<User> all = new ArrayList<>();
		repository.findAll().forEach(x -> all.add((User) x));
		return all; 					
	}
	
	@Override
	public User find(Long id) {
		return (User)repository.findById(id).get();
	}
	
	@Override
	public User update(User _User) {
		return (User)repository.save(_User);
	}
	
	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
	@Override
	public void delete(User _User) {
		repository.delete(_User);
	}
	
}
