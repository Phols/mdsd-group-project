package dk.sdu.mmmi.project.extension.phols.models;

import javax.persistence.*;
import java.util.*;
import java.time.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.security.Role;

@Entity
@Table(name = "T_BOOK")
public class Book extends Media {
	

	private String _isbn13;
	
	private Integer _pageCount;
	
	private String _language;
	
	
	public Book() { }
	
	public String getIsbn13() {
		return _isbn13;
	}
	public Integer getPageCount() {
		return _pageCount;
	}
	public String getLanguage() {
		return _language;
	}
	public void setIsbn13 (String isbn13) throws IllegalArgumentException {
		if (!(isbn13.length() == 13)) {
			throw new IllegalArgumentException("length of isbn13 must be == 13.");
		}
		this._isbn13 = isbn13;
	}
	
	public void setPageCount (Integer pageCount)  {
		this._pageCount = pageCount;
	}
	
	public void setLanguage (String language)  {
		this._language = language;
	}
	
}

