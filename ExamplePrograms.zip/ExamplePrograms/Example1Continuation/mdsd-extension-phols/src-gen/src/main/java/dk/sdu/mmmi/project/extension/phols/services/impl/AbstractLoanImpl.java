package dk.sdu.mmmi.project.extension.phols.services.impl;

import java.util.*;
import java.time.LocalDateTime;
import dk.sdu.mmmi.project.extension.phols.repositories.*;
import dk.sdu.mmmi.project.extension.phols.models.*;
import dk.sdu.mmmi.project.extension.phols.services.*;
import org.springframework.stereotype.Service;

public abstract class AbstractLoanImpl implements ILoan {
	
	protected LoanRepository repository;
	
	public AbstractLoanImpl(LoanRepository repository) {
		this.repository = repository;
	}
	
	
	@Override
	public Loan create(Loan _Loan) {
		return (Loan)repository.save(_Loan);
	}
	
	@Override
	public List<Loan> findAll() {
		List<Loan> all = new ArrayList<>();
		repository.findAll().forEach(x -> all.add((Loan) x));
		return all; 					
	}
	
	@Override
	public Loan find(Long id) {
		return (Loan)repository.findById(id).get();
	}
	
	@Override
	public Loan update(Loan _Loan) {
		return (Loan)repository.save(_Loan);
	}
	
	@Override
	public List<Loan> underdueLoans (LocalDateTime currDate  ) {
	List<Loan> _return = new ArrayList<>();
	repository.findAll().forEach(_return::add);
	for (Loan temp : _return) {
		if ((currDate.isBefore(temp.getEndDate())
		 && (currDate.equals(temp.getStartDate())
		 || !currDate.equals(temp.getArchivedDate())
		)
		)
		) {
			_return.remove(temp);
		} 
	}
	
	return _return;
	}
	@Override
	public List<Loan> overdueLoans (LocalDateTime currDate  ) {
	List<Loan> _return = new ArrayList<>();
	repository.findAll().forEach(_return::add);
	for (Loan temp : _return) {
		if ((currDate.isAfter(temp.getEndDate())
		 && !currDate.equals(temp.getArchivedDate())
		)
		) {
			_return.remove(temp);
		} 
	}
	
	return _return;
	}
}
